// wc-pages-main.jsx — HomePage, PredictionPage, CaptainPage

// ─── HomePage ─────────────────────────────────────────────────────────────────
const HomePage = ({ navigate, fixtures, demoMode }) => {
  const [collapsed, setCollapsed] = React.useState({});
  const toggle = (key) => setCollapsed(p => ({ ...p, [key]: !p[key] }));

  // Group fixtures by stage then matchday then date
  const grouped = React.useMemo(() => {
    const stages = {};
    fixtures.forEach(f => {
      const key = f.stage === 'Group Stage' ? `md_${f.matchday}` : f.stage;
      if (!stages[key]) stages[key] = { label: f.stage === 'Group Stage' ? `Matchday ${f.matchday}` : f.stage, stage: f.stage, matchday: f.matchday, byDate: {} };
      if (!stages[key].byDate[f.date]) stages[key].byDate[f.date] = [];
      stages[key].byDate[f.date].push(f);
    });
    return stages;
  }, [fixtures]);

  const stageOrder = ['md_1','md_2','md_3','Round of 32','Round of 16','Quarter-finals','Semi-finals','Third place','Final'];
  const orderedKeys = stageOrder.filter(k => grouped[k]);

  // "Today" strip — show when there are live/locked matches
  const liveOrLocked = fixtures.filter(f => f.status === 'live' || f.status === 'locked');
  const hasLive = fixtures.some(f => f.status === 'live');

  const daysToGo = Math.ceil((new Date('2026-06-11') - new Date('2026-06-05')) / 86400000);
  const heroDaysLabel = demoMode === 'pre' ? daysToGo : null;

  return (
    <div style={{ paddingBottom: 32 }}>
      {/* Hero */}
      <div style={{
        margin: '0 -16px 8px',
        background: 'linear-gradient(160deg, #0a1f12 0%, #0b1629 50%, #080e1a 100%)',
        borderBottom: '1px solid var(--border)',
        padding: '40px 24px 36px',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Subtle grid texture */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.03,
          backgroundImage: 'repeating-linear-gradient(0deg, #fff 0, #fff 1px, transparent 1px, transparent 40px), repeating-linear-gradient(90deg, #fff 0, #fff 1px, transparent 1px, transparent 40px)',
          pointerEvents: 'none',
        }} />
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--green)', marginBottom: 6 }}>
                FIFA World Cup 2026
              </div>
              <h1 style={{ fontSize: 28, fontWeight: 900, color: 'var(--text-primary)', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
                Predictions
              </h1>
              <div style={{ height: 2, width: 32, background: 'var(--green)', margin: '10px 0' }} />
              <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                48 teams · 104 matches · Jun 11 – Jul 19
              </p>
              {/* Mini stats row */}
              <div style={{ display: 'flex', gap: 24, marginTop: 20, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                {[['5','Picks'],['#6','Rank'],['11 pts','Points']].map(([val,lbl]) => (
                  <div key={lbl}>
                    <div style={{ fontSize: 17, fontWeight: 900, color: lbl === 'Rank' ? 'var(--green)' : 'var(--text-primary)', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{val}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginTop: 3 }}>{lbl}</div>
                  </div>
                ))}
              </div>
            </div>
            {heroDaysLabel !== null ? (
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 52, fontWeight: 900, color: 'var(--green)', lineHeight: 1, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums' }}>
                  {heroDaysLabel}
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 4 }}>
                  days to go
                </div>
              </div>
            ) : (
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 11, color: 'var(--green)', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Matchday 1</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>In progress</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Today strip */}
      {liveOrLocked.length > 0 && (
        <div style={{
          border: '1px solid rgba(34,197,94,0.25)',
          borderRadius: 12, background: 'rgba(34,197,94,0.04)',
          padding: '12px 16px', marginBottom: 8,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            {hasLive && <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--green)', animation: 'pulseDot 1.4s infinite', flexShrink: 0 }} />}
            <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--green)' }}>
              {hasLive ? 'Live Now' : 'Today'}
            </span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {liveOrLocked.map(f => (
              <MatchCard key={f.id} fixture={f} onClick={() => navigate('prediction', { matchId: f.id })} />
            ))}
          </div>
        </div>
      )}

      {/* Fixture sections */}
      {orderedKeys.map((key, idx) => {
        const section = grouped[key];
        const isActive = key === 'md_1' && demoMode !== 'pre';
        const isFinished = section.stage === 'Group Stage' && demoMode === 'post' && section.matchday === 1;
        const isCollapsed = collapsed[key];
        const dates = Object.keys(section.byDate).sort();
        const allFixtures = dates.flatMap(d => section.byDate[d]);
        const dateSub = dates.length > 0
          ? `${new Date(dates[0]+'T12:00:00').toLocaleDateString('en-GB',{day:'numeric',month:'short'})} – ${new Date(dates[dates.length-1]+'T12:00:00').toLocaleDateString('en-GB',{day:'numeric',month:'short'})}`
          : '';

        return (
          <div key={key}>
            <button
              onClick={() => toggle(key)}
              style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
            >
              <SectionDivider
                label={section.label}
                sub={dateSub}
                active={isActive}
                finished={isFinished}
              />
            </button>

            {!isCollapsed && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {dates.map(date => (
                  <div key={date}>
                    {dates.length > 1 && <DateLabel date={date} />}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      {section.byDate[date].map(f => (
                        <MatchCard
                          key={f.id}
                          fixture={f}
                          onClick={(fx) => {
                            if (fx.status === 'upcoming' || fx.status === 'locked') navigate('prediction', { matchId: fx.id });
                          }}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {isCollapsed && (
              <div style={{ textAlign: 'center', padding: '8px 0 4px', fontSize: 12, color: 'var(--text-muted)' }}>
                {allFixtures.length} matches — tap to expand
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

// ─── PredictionPage ──────────────────────────────────────────────────────────
const WILDCARDS = [
  { id: 'confidence', icon: '🎯', name: 'Confidence', desc: 'Double your points if correct', badge: '×2 pts' },
  { id: 'underdog',   icon: '⚡', name: 'Underdog',   desc: '+3 bonus if predicted team wins against the odds', badge: '+3 bonus' },
  { id: 'chaos',      icon: '🎲', name: 'Chaos Card', desc: 'Predict a chaos event for extra points', badge: 'Risk/reward' },
];

const CHAOS_EVENTS = [
  { id: 'common', label: 'Common',  desc: 'Red card in the game',   bonus: '+1', color: 'var(--text-muted)'    },
  { id: 'medium', label: 'Medium',  desc: 'VAR overturned goal',    bonus: '+2', color: 'var(--text-secondary)' },
  { id: 'rare',   label: 'Rare',    desc: 'Player scores 2+ goals', bonus: '+3', color: 'var(--text-primary)'   },
];

const PredictionPage = ({ matchId, navigate, predictions, onSave }) => {
  const fixture = React.useMemo(() => WC_FIXTURES.find(f => f.id === matchId) || WC_FIXTURES[0], [matchId]);
  const existing = predictions[matchId];

  const [homeGoals, setHomeGoals] = React.useState(existing?.homeGoals ?? null);
  const [awayGoals, setAwayGoals] = React.useState(existing?.awayGoals ?? null);
  const [wildcard, setWildcard]   = React.useState(existing?.wildcard ?? null);
  const [chaos, setChaos]         = React.useState(null);
  const [saved, setSaved]         = React.useState(false);

  const t = (code) => WC_TEAMS[code] || { name: code, short: code, flag: null };
  const home = t(fixture.home);
  const away = t(fixture.away);
  const isLocked = fixture.status === 'locked';

  const result = homeGoals !== null && awayGoals !== null
    ? homeGoals > awayGoals ? `${home.short} win`
      : awayGoals > homeGoals ? `${away.short} win`
      : 'Draw'
    : null;

  const handleSave = () => {
    onSave(matchId, { homeGoals, awayGoals, wildcard, chaos, points: null, breakdown: [] });
    setSaved(true);
    setTimeout(() => navigate('home'), 800);
  };

  const fmtDate = (d) => {
    if (!d) return '';
    const dt = new Date(d + 'T12:00:00');
    return dt.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  };

  const GOALS = [0, 1, 2, 3, '4+'];

  const GoalPicker = ({ value, onChange, label }) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
        {label}
      </span>
      <div style={{ display: 'flex', gap: 8 }}>
        {GOALS.map(g => {
          const active = value === g || (g === '4+' && value >= 4);
          return (
            <button
              key={g}
              onClick={() => !isLocked && onChange(typeof g === 'number' ? g : 4)}
              style={{
                flex: 1, minHeight: 48, borderRadius: 10,
                background: active ? 'var(--green)' : 'var(--surface-alt)',
                border: `1.5px solid ${active ? 'var(--green)' : 'var(--border)'}`,
                color: active ? '#000' : 'var(--text-secondary)',
                fontSize: 16, fontWeight: 800, cursor: isLocked ? 'not-allowed' : 'pointer',
                transition: 'all 0.12s',
                fontVariantNumeric: 'tabular-nums',
                opacity: isLocked ? 0.5 : 1,
              }}
            >{g}</button>
          );
        })}
      </div>
    </div>
  );

  return (
    <div style={{ paddingBottom: 32 }}>
      <BackButton onClick={() => navigate('home')} />

      {/* Match header */}
      <div style={{
        background: 'var(--surface)', border: '1px solid var(--border)',
        borderRadius: 16, padding: '20px 20px 16px', marginBottom: 20,
      }}>
        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          {fixture.group ? `Group ${fixture.group}` : fixture.stage} · {fmtDate(fixture.date)}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 8 }}>
            <Flag code={home.flag} size={36} />
            <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>{home.name}</span>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text-primary)' }}>{fixture.time}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{fixture.venue.split(',')[0]}</div>
            {isLocked && (
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 6, fontWeight: 600 }}>Locked — predictions closed</div>
            )}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
            <Flag code={away.flag} size={36} />
            <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>{away.name}</span>
          </div>
        </div>
      </div>

      {/* Score pickers */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 16 }}>
          Your Prediction
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <GoalPicker value={homeGoals} onChange={setHomeGoals} label={`${home.short} goals`} />
          <GoalPicker value={awayGoals} onChange={setAwayGoals} label={`${away.short} goals`} />
        </div>

        {result && (
          <div style={{
            marginTop: 16, padding: '10px 16px', borderRadius: 10,
            background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.2)',
            textAlign: 'center', fontSize: 13, fontWeight: 700, color: 'var(--green)',
          }}>
            Result: {result}
          </div>
        )}
      </div>

      {/* Wildcards */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 14 }}>
          Wildcard (optional)
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {WILDCARDS.map(wc => {
            const active = wildcard === wc.id;
            return (
              <button
                key={wc.id}
                onClick={() => !isLocked && setWildcard(active ? null : wc.id)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px',
                  borderRadius: 12, background: active ? 'rgba(34,197,94,0.06)' : 'var(--surface-alt)',
                  border: `1.5px solid ${active ? 'var(--green)' : 'var(--border)'}`,
                  cursor: isLocked ? 'not-allowed' : 'pointer', textAlign: 'left',
                  transition: 'border-color 0.15s, background 0.15s',
                  opacity: isLocked ? 0.5 : 1,
                }}
              >
                <span style={{ fontSize: 24 }}>{wc.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: active ? 'var(--text-primary)' : 'var(--text-secondary)' }}>
                    {wc.name}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 1 }}>{wc.desc}</div>
                </div>
                <span style={{
                  fontSize: 11, fontWeight: 600, padding: '3px 8px', borderRadius: 99,
                  background: 'var(--surface)',
                  border: `1px solid ${active ? 'rgba(34,197,94,0.35)' : 'var(--border)'}`,
                  color: active ? 'var(--green)' : 'var(--text-muted)',
                }}>
                  {wc.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Chaos event picker */}
        {wildcard === 'chaos' && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 10 }}>
              Choose chaos event
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {CHAOS_EVENTS.map(ev => {
                const active = chaos === ev.id;
                return (
                  <button
                    key={ev.id}
                    onClick={() => setChaos(active ? null : ev.id)}
                    style={{
                      flex: 1, padding: '10px 8px', borderRadius: 10, textAlign: 'center',
                      background: active ? 'var(--surface-alt)' : 'var(--surface)',
                      border: `1.5px solid ${active ? ev.color : 'var(--border)'}`,
                      cursor: 'pointer', transition: 'all 0.15s',
                    }}
                  >
                    <div style={{ fontSize: 11, fontWeight: 700, color: ev.color }}>{ev.bonus}</div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', marginTop: 2 }}>{ev.label}</div>
                    <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 2 }}>{ev.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Save button */}
      <button
        onClick={handleSave}
        disabled={homeGoals === null || awayGoals === null || isLocked}
        style={{
          width: '100%', height: 52, borderRadius: 12, border: 'none', cursor: 'pointer',
          background: saved ? 'rgba(34,197,94,0.15)' : homeGoals === null || awayGoals === null ? 'var(--surface-alt)' : 'var(--green)',
          color: saved ? 'var(--green)' : homeGoals === null || awayGoals === null ? 'var(--text-muted)' : '#000',
          fontSize: 15, fontWeight: 800, letterSpacing: '-0.01em',
          transition: 'all 0.2s',
          opacity: isLocked ? 0.5 : 1,
        }}
      >
        {isLocked ? 'Predictions locked' : saved ? '✓ Saved!' : existing ? 'Update Prediction' : 'Save Prediction'}
      </button>
    </div>
  );
};

// ─── CaptainPage ──────────────────────────────────────────────────────────────
const CaptainPage = ({ captainTeam, onSelectCaptain }) => {
  const [selected, setSelected] = React.useState(captainTeam);
  const [confirmed, setConfirmed] = React.useState(!!captainTeam);

  const handleConfirm = () => {
    if (!selected || confirmed) return;
    onSelectCaptain(selected);
    setConfirmed(true);
  };

  return (
    <div style={{ paddingBottom: 32 }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 26, fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
          Captain Pick
        </h1>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>
          Choose one team to follow through the tournament
        </p>
      </div>

      {/* Scoring banner */}
      <div style={{
        background: 'var(--surface-alt)', border: '1px solid var(--border)',
        borderRadius: 12, padding: '12px 16px', marginBottom: 24,
        display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center',
      }}>
        {[['R32', '+1'], ['R16', '+1'], ['QF', '+2'], ['SF', '+2'], ['Final', '+3'], ['Winner', '+5']].map(([stage, pts]) => (
          <span key={stage} style={{ display: 'flex', gap: 3, alignItems: 'center', marginRight: 4 }}>
            <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{stage}</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--green)' }}>{pts}</span>
            <span style={{ fontSize: 11, color: 'var(--border)' }}>·</span>
          </span>
        ))}
        <div style={{ width: '100%', fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>
          Locks 18:00 on Thu 11 Jun — 1 hour before kick-off
        </div>
      </div>

      {/* Group grid */}
      {Object.entries(WC_GROUPS).map(([group, teams]) => (
        <div key={group} style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 10 }}>
            Group {group}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }} className="captain-grid">
            {teams.map(code => {
              const team = WC_TEAMS[code];
              const isSelected = selected === code;
              const isMyCaptain = confirmed && captainTeam === code;
              return (
                <button
                  key={code}
                  onClick={() => !confirmed && setSelected(isSelected ? null : code)}
                  style={{
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                    padding: '14px 8px', borderRadius: 12,
                    background: isSelected ? 'rgba(34,197,94,0.08)' : 'var(--surface)',
                    border: `${isSelected ? 2 : 1}px solid ${isSelected ? 'var(--green)' : 'var(--border)'}`,
                    cursor: confirmed ? 'not-allowed' : 'pointer',
                    transition: 'all 0.15s', position: 'relative',
                    opacity: confirmed && !isMyCaptain ? 0.4 : 1,
                  }}
                >
                  {isMyCaptain && (
                    <span style={{
                      position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)',
                      background: 'var(--green)', color: '#000', fontSize: 9, fontWeight: 800,
                      padding: '2px 7px', borderRadius: 99, letterSpacing: '0.06em', textTransform: 'uppercase',
                      whiteSpace: 'nowrap',
                    }}>Captain</span>
                  )}
                  {isSelected && !isMyCaptain && (
                    <span style={{
                      position: 'absolute', top: 4, right: 4,
                      width: 16, height: 16, borderRadius: '50%', background: 'var(--green)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 9, color: '#000', fontWeight: 900,
                    }}>✓</span>
                  )}
                  <Flag code={team?.flag} size={32} />
                  <span style={{ fontSize: 11, fontWeight: 600, color: isSelected ? 'var(--text-primary)' : 'var(--text-secondary)', textAlign: 'center', lineHeight: 1.2 }}>
                    {team?.short}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      ))}

      <button
        onClick={handleConfirm}
        disabled={!selected || confirmed}
        style={{
          width: '100%', height: 52, borderRadius: 12, border: 'none',
          cursor: !selected || confirmed ? 'not-allowed' : 'pointer',
          background: confirmed ? 'rgba(34,197,94,0.1)' : selected ? 'var(--green)' : 'var(--surface-alt)',
          color: confirmed ? 'var(--green)' : selected ? '#000' : 'var(--text-muted)',
          fontSize: 15, fontWeight: 800, transition: 'all 0.2s',
        }}
      >
        {confirmed
          ? `✓ ${WC_TEAMS[captainTeam]?.name} locked in`
          : selected ? `Confirm ${WC_TEAMS[selected]?.name} as Captain` : 'Select a team above'}
      </button>
    </div>
  );
};

Object.assign(window, { HomePage, PredictionPage, CaptainPage });
