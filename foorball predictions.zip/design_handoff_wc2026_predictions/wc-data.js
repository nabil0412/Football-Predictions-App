// wc-data.js — World Cup 2026 Predictions App: all static data

// ─── Teams ────────────────────────────────────────────────────────────────────
window.WC_TEAMS = {
  USA: { name: 'United States', short: 'USA', flag: 'us' },
  PAN: { name: 'Panama',        short: 'PAN', flag: 'pa' },
  BOL: { name: 'Bolivia',       short: 'BOL', flag: 'bo' },
  NZL: { name: 'New Zealand',   short: 'NZL', flag: 'nz' },
  ARG: { name: 'Argentina',     short: 'ARG', flag: 'ar' },
  CHI: { name: 'Chile',         short: 'CHI', flag: 'cl' },
  CRO: { name: 'Croatia',       short: 'CRO', flag: 'hr' },
  MAR: { name: 'Morocco',       short: 'MAR', flag: 'ma' },
  MEX: { name: 'Mexico',        short: 'MEX', flag: 'mx' },
  JAM: { name: 'Jamaica',       short: 'JAM', flag: 'jm' },
  VEN: { name: 'Venezuela',     short: 'VEN', flag: 've' },
  SUI: { name: 'Switzerland',   short: 'SUI', flag: 'ch' },
  CAN: { name: 'Canada',        short: 'CAN', flag: 'ca' },
  HON: { name: 'Honduras',      short: 'HON', flag: 'hn' },
  ALG: { name: 'Algeria',       short: 'ALG', flag: 'dz' },
  BEL: { name: 'Belgium',       short: 'BEL', flag: 'be' },
  BRA: { name: 'Brazil',        short: 'BRA', flag: 'br' },
  ECU: { name: 'Ecuador',       short: 'ECU', flag: 'ec' },
  SRB: { name: 'Serbia',        short: 'SRB', flag: 'rs' },
  CMR: { name: 'Cameroon',      short: 'CMR', flag: 'cm' },
  FRA: { name: 'France',        short: 'FRA', flag: 'fr' },
  URU: { name: 'Uruguay',       short: 'URU', flag: 'uy' },
  KOR: { name: 'South Korea',   short: 'KOR', flag: 'kr' },
  GEO: { name: 'Georgia',       short: 'GEO', flag: 'ge' },
  ESP: { name: 'Spain',         short: 'ESP', flag: 'es' },
  COL: { name: 'Colombia',      short: 'COL', flag: 'co' },
  AUS: { name: 'Australia',     short: 'AUS', flag: 'au' },
  POL: { name: 'Poland',        short: 'POL', flag: 'pl' },
  GER: { name: 'Germany',       short: 'GER', flag: 'de' },
  PAR: { name: 'Paraguay',      short: 'PAR', flag: 'py' },
  NGA: { name: 'Nigeria',       short: 'NGA', flag: 'ng' },
  AUT: { name: 'Austria',       short: 'AUT', flag: 'at' },
  POR: { name: 'Portugal',      short: 'POR', flag: 'pt' },
  PER: { name: 'Peru',          short: 'PER', flag: 'pe' },
  EGY: { name: 'Egypt',         short: 'EGY', flag: 'eg' },
  CZE: { name: 'Czech Republic',short: 'CZE', flag: 'cz' },
  ENG: { name: 'England',       short: 'ENG', flag: 'gb-eng' },
  SEN: { name: 'Senegal',       short: 'SEN', flag: 'sn' },
  IRN: { name: 'Iran',          short: 'IRN', flag: 'ir' },
  SVK: { name: 'Slovakia',      short: 'SVK', flag: 'sk' },
  NED: { name: 'Netherlands',   short: 'NED', flag: 'nl' },
  CRC: { name: 'Costa Rica',    short: 'CRC', flag: 'cr' },
  RSA: { name: 'South Africa',  short: 'RSA', flag: 'za' },
  HUN: { name: 'Hungary',       short: 'HUN', flag: 'hu' },
  ITA: { name: 'Italy',         short: 'ITA', flag: 'it' },
  GHA: { name: 'Ghana',         short: 'GHA', flag: 'gh' },
  KSA: { name: 'Saudi Arabia',  short: 'KSA', flag: 'sa' },
  JPN: { name: 'Japan',         short: 'JPN', flag: 'jp' },
};

// ─── Groups ───────────────────────────────────────────────────────────────────
window.WC_GROUPS = {
  A: ['USA', 'PAN', 'BOL', 'NZL'],
  B: ['ARG', 'CHI', 'CRO', 'MAR'],
  C: ['MEX', 'JAM', 'VEN', 'SUI'],
  D: ['CAN', 'HON', 'ALG', 'BEL'],
  E: ['BRA', 'ECU', 'SRB', 'CMR'],
  F: ['FRA', 'URU', 'KOR', 'GEO'],
  G: ['ESP', 'COL', 'AUS', 'POL'],
  H: ['GER', 'PAR', 'NGA', 'AUT'],
  I: ['POR', 'PER', 'EGY', 'CZE'],
  J: ['ENG', 'SEN', 'IRN', 'SVK'],
  K: ['NED', 'CRC', 'RSA', 'HUN'],
  L: ['ITA', 'GHA', 'KSA', 'JPN'],
};

// ─── Fixture generation ───────────────────────────────────────────────────────
(function () {
  const VENUES = [
    'MetLife Stadium, New York',
    'AT&T Stadium, Dallas',
    'SoFi Stadium, Los Angeles',
    'Rose Bowl, Pasadena',
    'Lumen Field, Seattle',
    'Gillette Stadium, Boston',
    'Hard Rock Stadium, Miami',
    'Arrowhead Stadium, Kansas City',
    'BMO Field, Toronto',
    'BC Place, Vancouver',
    'Estadio Azteca, Mexico City',
    'Estadio Akron, Guadalajara',
  ];

  const MD_DATES = {
    1: ['2026-06-11', '2026-06-12', '2026-06-13', '2026-06-14'],
    2: ['2026-06-15', '2026-06-16', '2026-06-17', '2026-06-18'],
    3: ['2026-06-19', '2026-06-20', '2026-06-21', '2026-06-22'],
  };

  const TIMES = ['13:00', '16:00', '19:00', '22:00'];

  // Matchday pairing scheme: [homeIdx, awayIdx] from each group's 4 teams
  const MD_PAIRINGS = [
    [[0, 1], [2, 3]],
    [[0, 2], [1, 3]],
    [[0, 3], [1, 2]],
  ];

  const groups = Object.entries(WC_GROUPS);
  let n = 1;
  const fixtures = [];

  for (let md = 1; md <= 3; md++) {
    const dates = MD_DATES[md];
    const pairings = MD_PAIRINGS[md - 1];
    groups.forEach(([group, teams], gi) => {
      pairings.forEach(([i, j], pi) => {
        const di = (gi * 2 + pi) % 4;
        const ti = (gi + pi + md) % 4;
        const vi = (gi * 2 + pi + md - 1) % VENUES.length;
        fixtures.push({
          id: `M${String(n).padStart(3, '0')}`,
          home: teams[i], away: teams[j],
          group, matchday: md, stage: 'Group Stage',
          date: dates[di], time: TIMES[ti], venue: VENUES[vi],
          status: 'upcoming', homeScore: null, awayScore: null, minute: null,
        });
        n++;
      });
    });
  }

  // Knockout stubs
  const KO = [
    { stage: 'Round of 32',    count: 16, dates: ['2026-06-27','2026-06-28','2026-06-29','2026-06-30'] },
    { stage: 'Round of 16',    count: 8,  dates: ['2026-07-03','2026-07-04','2026-07-05','2026-07-06'] },
    { stage: 'Quarter-finals', count: 4,  dates: ['2026-07-09','2026-07-10'] },
    { stage: 'Semi-finals',    count: 2,  dates: ['2026-07-14','2026-07-15'] },
    { stage: 'Third place',    count: 1,  dates: ['2026-07-18'] },
    { stage: 'Final',          count: 1,  dates: ['2026-07-19'] },
  ];

  KO.forEach(({ stage, count, dates }) => {
    for (let k = 0; k < count; k++) {
      fixtures.push({
        id: `M${String(n).padStart(3, '0')}`,
        home: 'TBD', away: 'TBD',
        group: null, matchday: null, stage,
        date: dates[k % dates.length],
        time: k % 2 === 0 ? '16:00' : '20:00',
        venue: VENUES[k % VENUES.length],
        status: 'upcoming', homeScore: null, awayScore: null, minute: null,
      });
      n++;
    }
  });

  window.WC_FIXTURES = fixtures;
})();

// ─── Demo overlays (applied when demoMode !== 'pre') ─────────────────────────
// 'live' mode: tournament in progress, some matches live/finished today
window.WC_DEMO_LIVE = {
  'M001': { homeScore: 2, awayScore: 0, status: 'finished' },   // USA 2-0 PAN ✓
  'M003': { homeScore: 1, awayScore: 1, status: 'finished' },   // ARG 1-1 CHI ✓
  'M005': { homeScore: 2, awayScore: 1, status: 'live', minute: 67 },  // MEX 2-1 JAM LIVE
  'M007': { homeScore: 0, awayScore: 0, status: 'live', minute: 31 },  // CAN 0-0 HON LIVE
  'M009': { homeScore: null, awayScore: null, status: 'locked' },       // BRA v ECU locked
  'M011': { homeScore: null, awayScore: null, status: 'locked' },       // FRA v URU locked
};

// 'post' mode: matchday 1 fully complete
window.WC_DEMO_POST = {
  'M001': { homeScore: 2, awayScore: 0, status: 'finished' },
  'M002': { homeScore: 0, awayScore: 2, status: 'finished' },
  'M003': { homeScore: 1, awayScore: 1, status: 'finished' },
  'M004': { homeScore: 3, awayScore: 0, status: 'finished' },
  'M005': { homeScore: 2, awayScore: 2, status: 'finished' },
  'M006': { homeScore: 0, awayScore: 1, status: 'finished' },
  'M007': { homeScore: 4, awayScore: 1, status: 'finished' },
  'M008': { homeScore: 2, awayScore: 0, status: 'finished' },
  'M009': { homeScore: 3, awayScore: 1, status: 'finished' },
  'M010': { homeScore: 1, awayScore: 0, status: 'finished' },
  'M011': { homeScore: 0, awayScore: 0, status: 'finished' },
  'M012': { homeScore: 2, awayScore: 1, status: 'finished' },
  'M013': { homeScore: 1, awayScore: 2, status: 'finished' },
  'M014': { homeScore: 0, awayScore: 0, status: 'finished' },
  'M015': { homeScore: 3, awayScore: 2, status: 'finished' },
  'M016': { homeScore: 1, awayScore: 1, status: 'finished' },
  'M017': { homeScore: 2, awayScore: 0, status: 'finished' },
  'M018': { homeScore: 0, awayScore: 1, status: 'finished' },
  'M019': { homeScore: 1, awayScore: 0, status: 'finished' },
  'M020': { homeScore: 2, awayScore: 2, status: 'finished' },
  'M021': { homeScore: 0, awayScore: 3, status: 'finished' },
  'M022': { homeScore: 1, awayScore: 0, status: 'finished' },
  'M023': { homeScore: 2, awayScore: 1, status: 'finished' },
  'M024': { homeScore: 0, awayScore: 2, status: 'finished' },
};

// ─── Global leaderboard ───────────────────────────────────────────────────────
window.WC_LEADERBOARD = [
  { id: 'u1',  name: 'Charlotte K.',  initials: 'CK', points: 47, rank: 1 },
  { id: 'u2',  name: 'Marcus T.',     initials: 'MT', points: 41, rank: 2 },
  { id: 'u3',  name: 'Priya S.',      initials: 'PS', points: 38, rank: 3 },
  { id: 'u4',  name: 'James W.',      initials: 'JW', points: 31, rank: 4 },
  { id: 'u5',  name: 'Sofia M.',      initials: 'SM', points: 29, rank: 5 },
  { id: 'you', name: 'You',           initials: 'YO', points: 24, rank: 6, isMe: true },
  { id: 'u7',  name: 'Lucas P.',      initials: 'LP', points: 21, rank: 7 },
  { id: 'u8',  name: 'Aisha R.',      initials: 'AR', points: 18, rank: 8 },
  { id: 'u9',  name: 'Tom H.',        initials: 'TH', points: 15, rank: 9 },
  { id: 'u10', name: 'Emma J.',       initials: 'EJ', points: 12, rank: 10 },
  { id: 'u11', name: 'Leon B.',       initials: 'LB', points: 10, rank: 11 },
  { id: 'u12', name: 'Zara K.',       initials: 'ZK', points: 8,  rank: 12 },
];

// ─── Leagues ──────────────────────────────────────────────────────────────────
window.WC_LEAGUES = [
  {
    id: 'l1', name: 'Office Predictions', code: 'OFFIC26',
    memberCount: 8, myRank: 2, myPoints: 24,
    members: [
      { id: 'u1',  name: 'Charlotte K.',  initials: 'CK', points: 31, rank: 1, diff: 0 },
      { id: 'you', name: 'You',           initials: 'YO', points: 24, rank: 2, diff: -7,  isMe: true },
      { id: 'u4',  name: 'James W.',      initials: 'JW', points: 19, rank: 3, diff: -12 },
      { id: 'u5',  name: 'Sofia M.',      initials: 'SM', points: 16, rank: 4, diff: -15 },
      { id: 'u7',  name: 'Lucas P.',      initials: 'LP', points: 14, rank: 5, diff: -17 },
      { id: 'u8',  name: 'Aisha R.',      initials: 'AR', points: 11, rank: 6, diff: -20 },
      { id: 'u9',  name: 'Tom H.',        initials: 'TH', points: 9,  rank: 7, diff: -22 },
      { id: 'u10', name: 'Emma J.',       initials: 'EJ', points: 5,  rank: 8, diff: -26 },
    ],
  },
  {
    id: 'l2', name: 'Uni Friends WC26', code: 'UNIFR26',
    memberCount: 12, myRank: 5, myPoints: 24,
    members: [
      { id: 'ua',  name: 'Daniel M.',     initials: 'DM', points: 38, rank: 1, diff: 0 },
      { id: 'ub',  name: 'Olivia R.',     initials: 'OR', points: 35, rank: 2, diff: -3 },
      { id: 'uc',  name: 'Noah G.',       initials: 'NG', points: 31, rank: 3, diff: -7 },
      { id: 'ud',  name: 'Isabella S.',   initials: 'IS', points: 26, rank: 4, diff: -12 },
      { id: 'you', name: 'You',           initials: 'YO', points: 24, rank: 5, diff: -14, isMe: true },
      { id: 'uf',  name: 'Ethan P.',      initials: 'EP', points: 20, rank: 6, diff: -18 },
      { id: 'ug',  name: 'Mia C.',        initials: 'MC', points: 17, rank: 7, diff: -21 },
      { id: 'uh',  name: 'Ryan T.',       initials: 'RT', points: 14, rank: 8, diff: -24 },
    ],
  },
];

// ─── Initial predictions (demo data) ─────────────────────────────────────────
window.WC_MY_PREDICTIONS_INIT = [
  {
    matchId: 'M001', homeGoals: 2, awayGoals: 0, wildcard: 'confidence',
    points: 8,
    breakdown: [
      { label: 'Correct result', pts: 3, correct: true },
      { label: 'USA goals (2)',  pts: 1, correct: true },
      { label: 'Panama goals (0)', pts: 1, correct: true },
      { label: 'Perfect prediction', pts: 1, correct: true },
      { label: 'Confidence ×2', pts: 2, correct: true },
    ],
  },
  {
    matchId: 'M003', homeGoals: 2, awayGoals: 0, wildcard: null,
    points: 3,
    breakdown: [
      { label: 'Correct result', pts: 3, correct: true },
      { label: 'Argentina goals (1)', pts: 1, correct: false },
      { label: 'Chile goals (0)',     pts: 1, correct: false },
    ],
  },
  {
    matchId: 'M005', homeGoals: 2, awayGoals: 1, wildcard: 'confidence',
    points: null, breakdown: [],
  },
  {
    matchId: 'M009', homeGoals: 3, awayGoals: 0, wildcard: 'underdog',
    points: null, breakdown: [],
  },
  {
    matchId: 'M013', homeGoals: 2, awayGoals: 0, wildcard: null,
    points: null, breakdown: [],
  },
];
