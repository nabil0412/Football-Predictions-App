// wc-components.jsx — Shared UI components: Flag, Badge, MatchCard, Navbar, BottomNav

// ─── Flag ─────────────────────────────────────────────────────────────────────
const Flag = ({ code, size = 28 }) => {
  if (!code || code === 'TBD') {
    return (
      <div style={{
        width: size * 1.4, height: size, borderRadius: 4,
        background: 'var(--surface-alt)', border: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: size * 0.4, color: 'var(--text-muted)', fontWeight: 700,
      }}>?</div>
    );
  }
  return (
    <img
      src={`https://flagcdn.com/w${size <= 24 ? 40 : 80}/${code}.png`}
      alt=""
      style={{
        width: size * 1.4, height: size,
        borderRadius: 4,
        objectFit: 'cover',
        boxShadow: '0 1px 4px rgba(0,0,0,0.4)',
        display: 'block',
      }}
      onError={e => { e.target.style.opacity = 0.3; }}
    />
  );
};

// ─── StatusBadge ─────────────────────────────────────────────────────────────
const StatusBadge = ({ status, minute }) => {
  const styles = {
    live:     { bg: '#f87171', color: '#fff' },
    finished: { bg: 'var(--surface-alt)', color: 'var(--text-muted)' },
    locked:   { bg: 'var(--surface-alt)', color: 'var(--text-secondary)', border: '1px solid var(--border)' },
    upcoming: { bg: 'transparent', color: 'var(--text-muted)', border: '1px solid var(--border)' },
  };
  const s = styles[status] || styles.upcoming;
  const label = status === 'live'
    ? (minute ? `${minute}'` : 'LIVE')
    : status === 'finished' ? 'FT'
    : status === 'locked' ? 'Locked'
    : 'Soon';

  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '3px 8px', borderRadius: 99, fontSize: 11, fontWeight: 700,
      letterSpacing: '0.04em', textTransform: 'uppercase',
      background: s.bg, color: s.color, border: s.border || 'none',
    }}>
      {status === 'live' && (
        <span style={{
          width: 6, height: 6, borderRadius: '50%', background: '#fff',
          animation: 'pulseDot 1.4s ease-in-out infinite',
          flexShrink: 0,
        }} />
      )}
      {label}
    </span>
  );
};

// ─── Avatar ───────────────────────────────────────────────────────────────────
const Avatar = ({ initials, size = 32 }) => (
  <div style={{
    width: size, height: size, borderRadius: '50%',
    background: 'rgba(255,255,255,0.05)',
    border: '1.5px solid var(--border)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: size * 0.35, fontWeight: 700,
    color: 'var(--text-secondary)',
    flexShrink: 0,
  }}>
    {initials}
  </div>
);

// ─── MatchCard ────────────────────────────────────────────────────────────────
const MatchCard = ({ fixture, onClick, myPick = null }) => {
  const [hovered, setHovered] = React.useState(false);
  const t = (code) => WC_TEAMS[code] || { name: code, short: code, flag: null };
  const home = t(fixture.home);
  const away = t(fixture.away);
  const { status, homeScore, awayScore, minute } = fixture;
  const isLive = status === 'live';
  const isDone = status === 'finished';
  const isLocked = status === 'locked';
  const isUpcoming = status === 'upcoming';

  // Date formatting
  const fmtDate = (d) => {
    if (!d) return '';
    const dt = new Date(d + 'T12:00:00');
    return dt.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }).toUpperCase();
  };

  const cardBg = isLive
    ? 'rgba(248,113,113,0.03)'
    : hovered && (isUpcoming || isLocked) ? 'rgba(255,255,255,0.02)'
    : 'var(--surface)';

  const cardBorder = isLive
    ? '1px solid rgba(248,113,113,0.25)'
    : hovered && (isUpcoming || isLocked) ? '1px solid rgba(34,197,94,0.3)'
    : '1px solid var(--border)';

  return (
    <div
      onClick={() => onClick && onClick(fixture)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: cardBg,
        border: cardBorder,
        borderRadius: 16,
        overflow: 'hidden',
        cursor: (isUpcoming || isLocked || isDone) ? 'pointer' : 'default',
        transition: 'transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease',
        transform: hovered && isUpcoming ? 'translateY(-1px)' : 'none',
        boxShadow: hovered && isUpcoming ? '0 8px 24px rgba(0,0,0,0.3)' : 'none',
      }}
    >
      {/* Top meta */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '14px 20px 0',
      }}>
        <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
          {fixture.group ? `Group ${fixture.group}` : fixture.stage}
        </span>
        {isLive && <StatusBadge status="live" minute={minute} />}
        {isDone && <StatusBadge status="finished" />}
        {isLocked && <StatusBadge status="locked" />}
      </div>

      {/* Teams + score row */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr auto 1fr',
        alignItems: 'center', gap: 8, padding: '14px 20px',
      }}>
        {/* Home */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6 }}>
          <Flag code={home.flag} size={28} />
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1 }}>
            {home.short}
          </span>
        </div>

        {/* Centre */}
        <div style={{ textAlign: 'center', minWidth: 90 }}>
          {(isLive || isDone) ? (
            <>
              <div style={{
                fontSize: 30, fontWeight: 900, letterSpacing: '-0.03em',
                fontVariantNumeric: 'tabular-nums', color: 'var(--text-primary)',
                lineHeight: 1,
              }}>
                {homeScore}
                <span style={{ color: 'var(--text-muted)', fontWeight: 300, margin: '0 6px' }}>—</span>
                {awayScore}
              </div>
              {isDone && (
                <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                  Full Time
                </div>
              )}
            </>
          ) : (
            <>
              <div style={{
                fontSize: 18, fontWeight: 800, color: 'var(--text-primary)',
                letterSpacing: '-0.01em',
              }}>
                {fixture.time}
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                {fmtDate(fixture.date)}
              </div>
              {isLocked && (
                <div style={{ fontSize: 10, color: 'var(--text-secondary)', marginTop: 4, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                  Locked
                </div>
              )}
            </>
          )}
        </div>

        {/* Away */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
          <Flag code={away.flag} size={28} />
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1 }}>
            {away.short}
          </span>
        </div>
      </div>

      {/* My pick chip (if exists) */}
      {myPick && (
        <div style={{
          margin: '0 20px 12px', padding: '8px 12px', borderRadius: 8,
          background: 'var(--surface-alt)', border: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
            My pick: <span style={{ color: 'var(--text-secondary)', fontWeight: 600 }}>
              {myPick.homeGoals}–{myPick.awayGoals}
            </span>
            {myPick.wildcard && <span style={{ color: 'var(--text-secondary)', marginLeft: 6 }}>
              {myPick.wildcard === 'confidence' ? '🎯' : myPick.wildcard === 'underdog' ? '⚡' : '🎲'}
            </span>}
          </span>
          {myPick.points != null && (
            <span style={{ fontSize: 12, fontWeight: 700, color: myPick.points > 0 ? 'var(--green)' : 'var(--red)' }}>
              {myPick.points > 0 ? '+' : ''}{myPick.points} pts
            </span>
          )}
        </div>
      )}

      {/* CTA strip for upcoming */}
      {isUpcoming && (
        <div style={{
          borderTop: '1px solid rgba(34,197,94,0.12)',
          background: 'rgba(34,197,94,0.04)',
          padding: '10px 20px',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          fontSize: 12, fontWeight: 600, color: 'var(--green)',
        }}>
          Predict this match →
        </div>
      )}
    </div>
  );
};

// ─── SectionDivider (Matchday header) ─────────────────────────────────────────
const SectionDivider = ({ label, sub, active = false, finished = false }) => (
  <div style={{
    display: 'flex', alignItems: 'center', gap: 12, margin: '44px 0 20px',
  }}>
    <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
      {active && (
        <span style={{
          width: 6, height: 6, borderRadius: '50%',
          background: 'var(--green)', flexShrink: 0,
          animation: 'pulseDot 1.4s ease-in-out infinite',
        }} />
      )}
      <span style={{
        fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase',
        color: finished ? 'var(--text-muted)' : active ? 'var(--green)' : 'var(--text-secondary)',
      }}>
        {label}
      </span>
      {sub && (
        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>· {sub}</span>
      )}
    </div>
    <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
  </div>
);

// ─── DateGroup label ──────────────────────────────────────────────────────────
const DateLabel = ({ date }) => {
  const dt = new Date(date + 'T12:00:00');
  const label = dt.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
  return (
    <div style={{ fontSize: 11, color: 'var(--text-muted)', margin: '16px 0 8px', fontWeight: 600, letterSpacing: '0.04em' }}>
      {label.toUpperCase()}
    </div>
  );
};

// ─── NavBar ───────────────────────────────────────────────────────────────────
const Navbar = ({ page, navigate, scrolled }) => {
  const navLinks = [
    { id: 'home',        label: 'Matches' },
    { id: 'leaderboard', label: 'Leaderboard' },
    { id: 'leagues',     label: 'Leagues' },
    { id: 'mypicks',     label: 'My Picks' },
  ];

  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 100,
      height: 56,
      background: scrolled
        ? 'rgba(15,25,41,0.97)'
        : 'rgba(15,25,41,0.85)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      borderBottom: '1px solid var(--border)',
      transition: 'background 0.2s',
    }}>
      <div style={{
        maxWidth: 720, margin: '0 auto', height: '100%',
        display: 'flex', alignItems: 'center', padding: '0 16px', gap: 0,
      }}>
        {/* Logo */}
        <button
          onClick={() => navigate('home')}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: 'none', border: 'none', cursor: 'pointer', padding: 0,
          }}
        >
          <div style={{
            width: 30, height: 30, borderRadius: 8,
            background: 'var(--green)', display: 'flex',
            alignItems: 'center', justifyContent: 'center',
            fontSize: 16,
          }}>⚽</div>
          <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>
            WC <span style={{ color: 'var(--green)' }}>2026</span>
          </span>
        </button>

        {/* Desktop nav links */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 2,
          flex: 1, justifyContent: 'center',
        }} className="desktop-nav">
          {navLinks.map(link => (
            <button
              key={link.id}
              onClick={() => navigate(link.id)}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                padding: '6px 14px', borderRadius: 99, fontSize: 13, fontWeight: 600,
                color: page === link.id ? 'var(--text-primary)' : 'var(--text-secondary)',
                background: page === link.id ? 'rgba(34,197,94,0.12)' : 'none',
                transition: 'all 0.15s',
              }}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginLeft: 'auto' }}>
          <button
            onClick={() => navigate('captain')}
            style={{
              background: 'var(--surface-alt)', border: '1px solid var(--border)',
              borderRadius: 99, padding: '5px 12px', cursor: 'pointer',
              fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)',
            }}
          >
            Captain
          </button>
          <div style={{
            width: 32, height: 32, borderRadius: '50%',
            background: 'rgba(34,197,94,0.15)', border: '2px solid rgba(34,197,94,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 12, fontWeight: 700, color: 'var(--green)', cursor: 'pointer',
          }}>
            YO
          </div>
        </div>
      </div>
    </nav>
  );
};

// ─── BottomNav (mobile) ───────────────────────────────────────────────────────
const BottomNav = ({ page, navigate }) => {
  const items = [
    { id: 'home',        icon: IconBall,     label: 'Matches' },
    { id: 'leaderboard', icon: IconTrophy,   label: 'Ranks' },
    { id: 'leagues',     icon: IconUsers,    label: 'Leagues' },
    { id: 'mypicks',     icon: IconCheck,    label: 'My Picks' },
    { id: 'captain',     icon: IconStar,     label: 'Captain' },
  ];
  return (
    <nav style={{
      position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 100,
      height: 60,
      background: 'rgba(15,25,41,0.97)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      borderTop: '1px solid var(--border)',
      display: 'flex',
    }} className="bottom-nav">
      {items.map(item => {
        const active = page === item.id;
        return (
          <button
            key={item.id}
            onClick={() => navigate(item.id)}
            style={{
              flex: 1, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 3,
              background: 'none', border: 'none', cursor: 'pointer',
              color: active ? 'var(--green)' : 'var(--text-muted)',
              transition: 'color 0.15s',
            }}
          >
            <item.icon size={20} />
            <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.03em' }}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};

// ─── Minimal SVG icons ────────────────────────────────────────────────────────
const Svg = ({ size, children, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"
    {...rest}>
    {children}
  </svg>
);

const IconBall    = ({ size = 20 }) => <Svg size={size}><circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0 1 7.07 17.07M12 2a10 10 0 0 0-7.07 17.07M12 22V12M4.93 4.93l4.24 4.24M19.07 4.93l-4.24 4.24M2 12h4M18 12h4"/></Svg>;
const IconTrophy  = ({ size = 20 }) => <Svg size={size}><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/></Svg>;
const IconUsers   = ({ size = 20 }) => <Svg size={size}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></Svg>;
const IconCheck   = ({ size = 20 }) => <Svg size={size}><polyline points="20 6 9 17 4 12"/></Svg>;
const IconStar    = ({ size = 20 }) => <Svg size={size}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></Svg>;
const IconArrow   = ({ size = 20 }) => <Svg size={size}><polyline points="15 18 9 12 15 6"/></Svg>;
const IconEdit    = ({ size = 16 }) => <Svg size={size}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></Svg>;
const IconCopy    = ({ size = 16 }) => <Svg size={size}><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></Svg>;
const IconPlus    = ({ size = 16 }) => <Svg size={size}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Svg>;
const IconSync    = ({ size = 16 }) => <Svg size={size}><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></Svg>;
const IconChevron = ({ size = 16, down = false }) => (
  <Svg size={size} style={{ transform: down ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
    <polyline points="18 15 12 9 6 15"/>
  </Svg>
);

// ─── Toast ────────────────────────────────────────────────────────────────────
const Toast = ({ message }) => {
  if (!message) return null;
  return (
    <div style={{
      position: 'fixed', bottom: 80, left: '50%', transform: 'translateX(-50%)',
      background: 'var(--surface-alt)', border: '1px solid var(--border)',
      borderRadius: 99, padding: '10px 20px', zIndex: 200,
      fontSize: 13, fontWeight: 600, color: 'var(--text-primary)',
      boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
      animation: 'slideUp 0.2s ease',
    }}>
      {message}
    </div>
  );
};

// ─── Back button ──────────────────────────────────────────────────────────────
const BackButton = ({ onClick, label = 'Back' }) => (
  <button
    onClick={onClick}
    style={{
      display: 'flex', alignItems: 'center', gap: 6,
      background: 'none', border: 'none', cursor: 'pointer',
      color: 'var(--text-secondary)', fontSize: 13, fontWeight: 600, padding: 0,
      marginBottom: 20,
    }}
  >
    <IconArrow size={16} />
    {label}
  </button>
);

// Export everything to window
Object.assign(window, {
  Flag, StatusBadge, Avatar, MatchCard,
  SectionDivider, DateLabel,
  Navbar, BottomNav, Toast, BackButton,
  Svg, IconBall, IconTrophy, IconUsers, IconCheck,
  IconStar, IconArrow, IconEdit, IconCopy,
  IconPlus, IconSync, IconChevron,
});
