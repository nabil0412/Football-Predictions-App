// wc-app.jsx — App root, routing, state management, tweaks

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "demoMode": "live",
  "accentColor": "#22c55e"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // ── Routing ──────────────────────────────────────────────────────────────
  const [page, setPage]     = React.useState('home');
  const [params, setParams] = React.useState({});
  const navigate = (to, p = {}) => { setPage(to); setParams(p); window.scrollTo(0, 0); };

  // ── Scroll detection for navbar ──────────────────────────────────────────
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const el = document.getElementById('app-scroll');
    if (!el) return;
    const onScroll = () => setScrolled(el.scrollTop > 10);
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  // ── Predictions state ────────────────────────────────────────────────────
  const [predictions, setPredictions] = React.useState(() => {
    try {
      const stored = localStorage.getItem('wc2026_preds');
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    return WC_MY_PREDICTIONS_INIT.reduce((acc, p) => ({ ...acc, [p.matchId]: p }), {});
  });

  const savePrediction = (matchId, pick) => {
    const updated = { ...predictions, [matchId]: { ...pick, matchId } };
    setPredictions(updated);
    try { localStorage.setItem('wc2026_preds', JSON.stringify(updated)); } catch (e) {}
  };

  // ── Captain state ─────────────────────────────────────────────────────────
  const [captainTeam, setCaptainTeam] = React.useState(() =>
    localStorage.getItem('wc2026_captain') || null
  );
  const selectCaptain = (code) => {
    setCaptainTeam(code);
    try { localStorage.setItem('wc2026_captain', code); } catch (e) {}
  };

  // ── My leagues ────────────────────────────────────────────────────────────
  const [myLeagues, setMyLeagues] = React.useState(['l1', 'l2']);

  // ── Toast ─────────────────────────────────────────────────────────────────
  const [toast, setToast] = React.useState(null);
  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2400);
  };

  // ── Compute fixtures with demo overlay ───────────────────────────────────
  const fixtures = React.useMemo(() => {
    const overlay = t.demoMode === 'live' ? WC_DEMO_LIVE
                  : t.demoMode === 'post' ? WC_DEMO_POST
                  : {};
    return WC_FIXTURES.map(f => {
      if (overlay[f.id]) return { ...f, ...overlay[f.id] };
      return f;
    });
  }, [t.demoMode]);

  // ── CSS accent override ───────────────────────────────────────────────────
  React.useEffect(() => {
    document.documentElement.style.setProperty('--green', t.accentColor);
    // derive glow
    document.documentElement.style.setProperty('--green-glow', t.accentColor + '26');
  }, [t.accentColor]);

  // ── Render ────────────────────────────────────────────────────────────────
  const contentPad = { maxWidth: 720, margin: '0 auto', padding: '16px 16px 80px' };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar page={page} navigate={navigate} scrolled={scrolled} />

      <div id="app-scroll" style={{ flex: 1, overflowY: 'auto' }}>
        <div style={contentPad}>
          {page === 'home' && (
            <HomePage
              navigate={navigate}
              fixtures={fixtures}
              demoMode={t.demoMode}
            />
          )}
          {page === 'prediction' && (
            <PredictionPage
              matchId={params.matchId}
              navigate={navigate}
              predictions={predictions}
              onSave={savePrediction}
            />
          )}
          {page === 'mypicks' && (
            <MyPicksPage
              navigate={navigate}
              predictions={predictions}
            />
          )}
          {page === 'leaderboard' && (
            <LeaderboardPage />
          )}
          {page === 'leagues' && (
            <LeaguesPage
              navigate={navigate}
              myLeagues={myLeagues}
              onCreateLeague={(l) => showToast(`"${l.name}" created!`)}
              showToast={showToast}
            />
          )}
          {page === 'league-detail' && (
            <LeagueDetailPage
              leagueId={params.leagueId}
              navigate={navigate}
              showToast={showToast}
            />
          )}
          {page === 'captain' && (
            <CaptainPage
              captainTeam={captainTeam}
              onSelectCaptain={selectCaptain}
            />
          )}
          {page === 'admin' && (
            <AdminPage />
          )}
        </div>
      </div>

      <BottomNav page={page} navigate={navigate} />
      <Toast message={toast} />

      {/* Tweaks */}
      <TweaksPanel>
        <TweakSection label="Demo State" />
        <TweakRadio
          label="Mode"
          value={t.demoMode}
          options={['pre', 'live', 'post']}
          onChange={v => setTweak('demoMode', v)}
        />
        <TweakSection label="Accent" />
        <TweakColor
          label="Green"
          value={t.accentColor}
          options={['#22c55e', '#16a34a', '#4ade80', '#34d399']}
          onChange={v => setTweak('accentColor', v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
