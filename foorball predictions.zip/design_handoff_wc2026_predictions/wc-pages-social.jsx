// wc-pages-social.jsx — LeaderboardPage, LeaguesPage, LeagueDetailPage

// ─── LeaderboardPage ──────────────────────────────────────────────────────────
const LeaderboardPage = () => {
  const board = WC_LEADERBOARD;
  const top3 = board.slice(0, 3);
  const rest = board.slice(3);
  const max = board[0].points;

  const medals = ['🥇','🥈','🥉'];
  const podiumOrder = [1, 0, 2]; // silver, gold, bronze display order

  return (
    <div style={{ paddingBottom: 32 }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, paddingTop: 8 }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>Leaderboard</h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>2,847 players</p>
        </div>
        <div style={{
          background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.25)',
          borderRadius: 99, padding: '6px 14px', fontSize: 13, fontWeight: 700, color: 'var(--green)',
        }}>
          Your rank: #6
        </div>
      </div>

      {/* Podium */}
      <div style={{
        background: 'var(--surface)', border: '1px solid var(--border)',
        borderRadius: 20, padding: '24px 16px 0', marginBottom: 20, overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 4 }}>
          {podiumOrder.map((idx) => {
            const user = top3[idx];
            const heights = [140, 160, 120]; // silver, gold, bronze
            const h = heights[podiumOrder.indexOf(idx)];
            const isGold = idx === 0;
            return (
              <div key={user.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
                {/* User info above podium */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, marginBottom: 8 }}>
                  <span style={{ fontSize: 20 }}>{medals[idx]}</span>
                  <Avatar initials={user.initials} size={isGold ? 40 : 34} />
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)', textAlign: 'center' }}>
                    {user.name.split(' ')[0]}
                  </span>
                  <span style={{
                    fontSize: 13, fontWeight: 900, color: 'var(--text-primary)',
                    fontVariantNumeric: 'tabular-nums',
                  }}>
                    {user.points} <span style={{ fontSize: 10, fontWeight: 600 }}>pts</span>
                  </span>
                </div>
                {/* Podium block */}
                <div style={{
                  width: '100%', height: h,
                  background: 'var(--surface-alt)',
                  borderTop: `2px solid var(--border)`,
                  borderRadius: '4px 4px 0 0',
                  animation: 'scaleIn 0.4s ease both',
                  animationDelay: `${podiumOrder.indexOf(idx) * 0.1}s`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <span style={{ fontSize: 22, fontWeight: 900, color: 'var(--border)', fontVariantNumeric: 'tabular-nums' }}>
                    {idx + 1}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rest of leaderboard */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {rest.map((user, i) => (
          <div
            key={user.id}
            style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 16px', borderRadius: 12,
              background: user.isMe ? 'rgba(34,197,94,0.05)' : 'transparent',
              border: `1px solid ${user.isMe ? 'rgba(34,197,94,0.2)' : 'transparent'}`,
              animation: user.isMe ? 'pulseMe 2s ease 0.5s both' : 'none',
            }}
          >
            <span style={{
              width: 28, textAlign: 'center', fontSize: 13, fontWeight: 700,
              color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums',
            }}>
              {user.rank}
            </span>
            <Avatar initials={user.initials} size={34} />
            <span style={{ flex: 1, fontSize: 14, fontWeight: user.isMe ? 700 : 500, color: user.isMe ? 'var(--green)' : 'var(--text-primary)' }}>
              {user.name}
              {user.isMe && <span style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600, marginLeft: 6 }}>YOU</span>}
            </span>
            {/* Progress bar — hidden on mobile via CSS class */}
            <div style={{ width: 80, height: 4, borderRadius: 99, background: 'var(--border)', overflow: 'hidden' }} className="lb-bar">
              <div style={{
                height: '100%', borderRadius: 99,
                width: `${(user.points / max) * 100}%`,
                background: user.isMe ? 'var(--green)' : 'var(--text-muted)',
                transition: 'width 0.6s ease',
              }} />
            </div>
            <span style={{
              fontSize: 14, fontWeight: 800, color: user.isMe ? 'var(--green)' : 'var(--text-primary)',
              fontVariantNumeric: 'tabular-nums', minWidth: 48, textAlign: 'right',
            }}>
              {user.points} <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)' }}>pts</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── LeaguesPage ──────────────────────────────────────────────────────────────
const LeaguesPage = ({ navigate, myLeagues, onJoinLeague, onCreateLeague, showToast }) => {
  const [tab, setTab] = React.useState('mine');
  const [createName, setCreateName] = React.useState('');
  const [joinCode, setJoinCode] = React.useState('');
  const [createdCode, setCreatedCode] = React.useState(null);

  const leagues = WC_LEAGUES.filter(l => myLeagues.includes(l.id));

  const handleCreate = () => {
    if (!createName.trim()) return;
    const code = createName.replace(/\s+/g, '').toUpperCase().slice(0, 6) + Math.floor(Math.random() * 99);
    setCreatedCode(code);
    onCreateLeague && onCreateLeague({ name: createName, code });
  };

  const handleJoin = () => {
    if (!joinCode.trim()) return;
    showToast('League not found — try a different code');
    setJoinCode('');
  };

  const tabStyle = (id) => ({
    flex: 1, height: 36, borderRadius: 8, border: 'none', cursor: 'pointer',
    background: tab === id ? 'var(--surface)' : 'none',
    color: tab === id ? 'var(--text-primary)' : 'var(--text-muted)',
    fontSize: 13, fontWeight: 700, transition: 'all 0.15s',
  });

  return (
    <div style={{ paddingBottom: 32 }}>
      <h1 style={{ fontSize: 26, fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.02em', marginBottom: 20, paddingTop: 8 }}>
        Leagues
      </h1>

      {/* Tabs */}
      <div style={{
        display: 'flex', gap: 4, background: 'var(--surface-alt)',
        borderRadius: 10, padding: 4, marginBottom: 20,
      }}>
        <button style={tabStyle('mine')} onClick={() => setTab('mine')}>My Leagues</button>
        <button style={tabStyle('create')} onClick={() => setTab('create')}>Create</button>
        <button style={tabStyle('join')} onClick={() => setTab('join')}>Join</button>
      </div>

      {/* My leagues */}
      {tab === 'mine' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {leagues.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 16px' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🏆</div>
              <p style={{ color: 'var(--text-secondary)', fontWeight: 600, fontSize: 15 }}>You're not in any leagues</p>
              <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 4 }}>Create one or join with a code</p>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 16 }}>
                <button onClick={() => setTab('create')} style={{ background: 'var(--green)', color: '#000', border: 'none', borderRadius: 99, padding: '8px 20px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Create</button>
                <button onClick={() => setTab('join')} style={{ background: 'var(--surface-alt)', color: 'var(--text-secondary)', border: '1px solid var(--border)', borderRadius: 99, padding: '8px 20px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Join</button>
              </div>
            </div>
          ) : leagues.map(league => (
            <button
              key={league.id}
              onClick={() => navigate('league-detail', { leagueId: league.id })}
              style={{
                display: 'block', width: '100%', textAlign: 'left',
                background: 'var(--surface)', border: '1px solid var(--border)',
                borderRadius: 16, padding: '16px', cursor: 'pointer',
                transition: 'border-color 0.15s',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>🏆 {league.name}</span>
                <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>{league.memberCount} members</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 8 }}>
                {league.myRank === 1 ? '🥇 You\'re leading!' : `You're in ${league.myRank}${['st','nd','rd'][league.myRank-1]||'th'} place`} · {league.myPoints} pts
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'monospace', letterSpacing: '0.08em' }}>
                  Code: {league.code}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--green)' }}>View →</span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Create */}
      {tab === 'create' && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 16 }}>Create a private league</div>
          {!createdCode ? (
            <>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>League name</label>
                <input
                  value={createName}
                  onChange={e => setCreateName(e.target.value)}
                  placeholder="e.g. Office Predictions"
                  style={{
                    width: '100%', padding: '12px 14px', borderRadius: 10,
                    background: 'var(--surface-alt)', border: '1px solid var(--border)',
                    color: 'var(--text-primary)', fontSize: 14, outline: 'none',
                    fontFamily: 'inherit',
                  }}
                />
              </div>
              <button
                onClick={handleCreate}
                disabled={!createName.trim()}
                style={{
                  width: '100%', height: 48, borderRadius: 10, border: 'none',
                  background: createName.trim() ? 'var(--green)' : 'var(--surface-alt)',
                  color: createName.trim() ? '#000' : 'var(--text-muted)',
                  fontSize: 14, fontWeight: 800, cursor: createName.trim() ? 'pointer' : 'not-allowed',
                }}
              >
                Create League
              </button>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '8px 0' }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>🎉</div>
              <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>{createName}</p>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 16 }}>Share this code to invite friends</p>
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 10,
                background: 'var(--surface-alt)', border: '1px solid var(--border)',
                borderRadius: 10, padding: '12px 20px',
              }}>
                <span style={{ fontSize: 20, fontWeight: 900, letterSpacing: '0.15em', fontFamily: 'monospace', color: 'var(--green)' }}>
                  {createdCode}
                </span>
                <button
                  onClick={() => { navigator.clipboard.writeText(createdCode); showToast('Code copied!'); }}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0 }}
                >
                  <IconCopy size={16} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Join */}
      {tab === 'join' && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 16 }}>Join with invite code</div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Invite code</label>
            <input
              value={joinCode}
              onChange={e => setJoinCode(e.target.value.toUpperCase())}
              placeholder="e.g. OFFIC26"
              maxLength={8}
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 10,
                background: 'var(--surface-alt)', border: '1px solid var(--border)',
                color: 'var(--text-primary)', fontSize: 16, fontWeight: 700,
                letterSpacing: '0.1em', fontFamily: 'monospace', outline: 'none',
              }}
            />
          </div>
          <button
            onClick={handleJoin}
            disabled={joinCode.length < 6}
            style={{
              width: '100%', height: 48, borderRadius: 10, border: 'none',
              background: joinCode.length >= 6 ? 'var(--green)' : 'var(--surface-alt)',
              color: joinCode.length >= 6 ? '#000' : 'var(--text-muted)',
              fontSize: 14, fontWeight: 800,
              cursor: joinCode.length >= 6 ? 'pointer' : 'not-allowed',
            }}
          >
            Join League
          </button>
        </div>
      )}
    </div>
  );
};

// ─── LeagueDetailPage ─────────────────────────────────────────────────────────
const LeagueDetailPage = ({ leagueId, navigate, showToast }) => {
  const league = WC_LEAGUES.find(l => l.id === leagueId) || WC_LEAGUES[0];
  const [copied, setCopied] = React.useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(league.code);
    setCopied(true);
    showToast('Invite code copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const max = league.members[0]?.points || 1;

  return (
    <div style={{ paddingBottom: 32 }}>
      <BackButton onClick={() => navigate('leagues')} label="Leagues" />

      {/* League header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
            🏆 {league.name}
          </h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>{league.memberCount} members</p>
        </div>
        <button
          onClick={copyCode}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            background: 'var(--surface-alt)', border: '1px solid var(--border)',
            borderRadius: 10, padding: '8px 12px', cursor: 'pointer',
            color: copied ? 'var(--green)' : 'var(--text-secondary)', fontSize: 12, fontWeight: 700,
            transition: 'all 0.15s',
          }}
        >
          <IconCopy size={14} />
          {copied ? 'Copied!' : league.code}
        </button>
      </div>

      {/* Members table */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
        {league.members.map((member, i) => (
          <div
            key={member.id}
            style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px',
              borderBottom: i < league.members.length - 1 ? '1px solid var(--border)' : 'none',
              background: member.isMe ? 'rgba(34,197,94,0.04)' : 'transparent',
            }}
          >
            <span style={{ width: 24, textAlign: 'center', fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}>
              {member.rank}
            </span>
            <Avatar initials={member.initials} size={32} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: member.isMe ? 700 : 500, color: member.isMe ? 'var(--green)' : 'var(--text-primary)' }}>
                {member.name}
                {member.isMe && <span style={{ fontSize: 10, color: 'var(--text-muted)', marginLeft: 5 }}>YOU</span>}
              </div>
              <div style={{ height: 3, marginTop: 4, borderRadius: 99, background: 'var(--border)', width: 80, overflow: 'hidden' }}>
                <div style={{ height: '100%', borderRadius: 99, width: `${(member.points / max) * 100}%`, background: member.isMe ? 'var(--green)' : 'var(--text-muted)' }} />
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: member.isMe ? 'var(--green)' : 'var(--text-primary)', fontVariantNumeric: 'tabular-nums' }}>
                {member.points} <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)' }}>pts</span>
              </div>
              <div style={{ fontSize: 11, color: member.rank === 1 ? 'var(--green)' : 'var(--text-muted)', fontWeight: 600 }}>
                {member.rank === 1 ? 'Leader' : member.diff}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { LeaderboardPage, LeaguesPage, LeagueDetailPage });
