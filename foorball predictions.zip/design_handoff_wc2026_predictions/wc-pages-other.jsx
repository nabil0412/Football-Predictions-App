// wc-pages-other.jsx — MyPicksPage, AdminPage

// ─── ScoreBreakdown ───────────────────────────────────────────────────────────
const ScoreBreakdown = ({ prediction, fixture }) => {
  const home = WC_TEAMS[fixture?.home] || { short: fixture?.home };
  const away = WC_TEAMS[fixture?.away] || { short: fixture?.away };
  const total = prediction.breakdown.reduce((s, r) => s + (r.correct ? r.pts : 0), 0);

  return (
    <div style={{
      background: 'var(--surface-alt)', borderTop: '1px solid var(--border)',
      padding: '14px 16px', animation: 'slideUp 0.2s ease',
    }}>
      {/* Match result summary */}
      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', marginBottom: 10 }}>
        {fixture ? `${home.short} ${fixture.homeScore}–${fixture.awayScore} ${away.short}` : ''}
        <span style={{ color: 'var(--text-muted)', fontWeight: 400, marginLeft: 6 }}>
          (Your pick: {prediction.homeGoals}–{prediction.awayGoals})
        </span>
      </div>
      {/* Row items */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {prediction.breakdown.map((row, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{
                width: 6, height: 6, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                background: row.correct ? 'var(--green)' : 'var(--border)',
              }} />
              <span style={{ fontSize: 13, color: row.correct ? 'var(--text-primary)' : 'var(--text-muted)' }}>
                {row.label}
              </span>
            </div>
            <span style={{ fontSize: 13, fontWeight: 700, color: row.correct ? 'var(--green)' : 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }}>
              {row.correct ? `+${row.pts}` : '—'}
            </span>
          </div>
        ))}
      </div>
      {/* Divider + total */}
      <div style={{ height: 1, background: 'var(--border)', margin: '10px 0' }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>Total</span>
        <span style={{
          fontSize: 16, fontWeight: 900, fontVariantNumeric: 'tabular-nums',
          color: total > 0 ? 'var(--green)' : total < 0 ? 'var(--red)' : 'var(--text-muted)',
        }}>
          {total > 0 ? '+' : ''}{total} pts
        </span>
      </div>
    </div>
  );
};

// ─── PredictionRow ────────────────────────────────────────────────────────────
const PredictionRow = ({ prediction, navigate, showBreakdown, onToggleBreakdown }) => {
  const fixture = WC_FIXTURES.find(f => f.id === prediction.matchId);
  if (!fixture) return null;

  const home = WC_TEAMS[fixture.home] || { short: fixture.home, flag: null };
  const away = WC_TEAMS[fixture.away] || { short: fixture.away, flag: null };
  const isFinished = fixture.status === 'finished';
  const isLive = fixture.status === 'live';
  const canEdit = fixture.status === 'upcoming';
  const wildcardIcons = { confidence: '🎯', underdog: '⚡', chaos: '🎲' };
  const fmtDate = (d) => d ? new Date(d + 'T12:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : '';

  return (
    <div style={{
      background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16,
      overflow: 'hidden',
    }}>
      <div
        onClick={() => isFinished && onToggleBreakdown()}
        style={{
          padding: '14px 16px', cursor: isFinished ? 'pointer' : 'default',
          display: 'flex', alignItems: 'flex-start', gap: 12,
        }}
      >
        {/* Teams + pick */}
        <div style={{ flex: 1 }}>
          {/* Teams row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <Flag code={home.flag} size={18} />
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>{home.short}</span>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>vs</span>
            <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>{away.short}</span>
            <Flag code={away.flag} size={18} />
          </div>
          {/* Pick + meta */}
          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            My pick: <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>
              {prediction.homeGoals}–{prediction.awayGoals}
            </span>
            {prediction.wildcard && (
              <span style={{ marginLeft: 6 }}>{wildcardIcons[prediction.wildcard]}</span>
            )}
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
            {fixture.group ? `Group ${fixture.group}` : fixture.stage} · {fmtDate(fixture.date)}
            {isLive && <span style={{ color: 'var(--red)', fontWeight: 700, marginLeft: 6 }}>● LIVE</span>}
          </div>
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
          {isFinished && prediction.points != null && (
            <span style={{
              fontSize: 16, fontWeight: 900, fontVariantNumeric: 'tabular-nums',
              color: prediction.points > 0 ? 'var(--green)' : 'var(--red)',
            }}>
              {prediction.points > 0 ? '+' : ''}{prediction.points}
              <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', marginLeft: 2 }}>pts</span>
            </span>
          )}
          {isFinished && prediction.points === 8 && (
            <span title="Perfect prediction">⭐</span>
          )}
          {canEdit && (
            <button
              onClick={() => navigate('prediction', { matchId: prediction.matchId })}
              style={{
                display: 'flex', alignItems: 'center', gap: 4,
                background: 'var(--surface-alt)', border: '1px solid var(--border)',
                borderRadius: 8, padding: '5px 10px', cursor: 'pointer',
                fontSize: 11, fontWeight: 700, color: 'var(--text-secondary)',
              }}
            >
              <IconEdit size={12} /> Edit
            </button>
          )}
          {isFinished && (
            <span style={{ color: 'var(--text-muted)', transition: 'transform 0.2s', display: 'block', transform: showBreakdown ? 'rotate(180deg)' : 'none' }}>
              <IconChevron size={16} down={false} />
            </span>
          )}
        </div>
      </div>

      {/* Score breakdown */}
      {isFinished && showBreakdown && (
        <ScoreBreakdown prediction={prediction} fixture={fixture} />
      )}
    </div>
  );
};

// ─── MyPicksPage ──────────────────────────────────────────────────────────────
const MyPicksPage = ({ navigate, predictions }) => {
  const [tab, setTab] = React.useState('upcoming');
  const [openBreakdowns, setOpenBreakdowns] = React.useState({});

  const toggleBreakdown = (matchId) =>
    setOpenBreakdowns(p => ({ ...p, [matchId]: !p[matchId] }));

  const allPicks = Object.values(predictions);
  const totalPoints = allPicks.reduce((s, p) => s + (p.points || 0), 0);

  const getStatus = (matchId) => {
    const f = WC_FIXTURES.find(x => x.id === matchId);
    return f?.status || 'upcoming';
  };

  const upcoming = allPicks.filter(p => {
    const s = getStatus(p.matchId);
    return s === 'upcoming' || s === 'locked' || s === 'live';
  });
  const finished = allPicks.filter(p => getStatus(p.matchId) === 'finished');

  const tabStyle = (id) => ({
    flex: 1, height: 36, borderRadius: 8, border: 'none', cursor: 'pointer',
    background: tab === id ? 'var(--surface)' : 'none',
    color: tab === id ? 'var(--text-primary)' : 'var(--text-muted)',
    fontSize: 13, fontWeight: 700, transition: 'all 0.15s',
  });

  const current = tab === 'upcoming' ? upcoming : finished;

  return (
    <div style={{ paddingBottom: 32 }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, paddingTop: 8 }}>
        <h1 style={{ fontSize: 26, fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
          My Picks
        </h1>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 28, fontWeight: 900, color: 'var(--green)', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>
            {totalPoints}
          </div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            total pts
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{
        display: 'flex', gap: 4, background: 'var(--surface-alt)',
        borderRadius: 10, padding: 4, marginBottom: 20,
      }}>
        <button style={tabStyle('upcoming')} onClick={() => setTab('upcoming')}>
          Upcoming · {upcoming.length}
        </button>
        <button style={tabStyle('finished')} onClick={() => setTab('finished')}>
          Finished · {finished.length}
        </button>
      </div>

      {current.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px 16px' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>⚽</div>
          <p style={{ color: 'var(--text-secondary)', fontWeight: 600, fontSize: 15 }}>
            {tab === 'upcoming' ? 'No picks yet' : 'No finished matches yet'}
          </p>
          {tab === 'upcoming' && (
            <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 4 }}>
              <button
                onClick={() => navigate('home')}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--green)', fontWeight: 700, fontSize: 13 }}
              >
                Browse matches →
              </button>
            </p>
          )}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {current.map(p => (
            <PredictionRow
              key={p.matchId}
              prediction={p}
              navigate={navigate}
              showBreakdown={!!openBreakdowns[p.matchId]}
              onToggleBreakdown={() => toggleBreakdown(p.matchId)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// ─── AdminPage ────────────────────────────────────────────────────────────────
const AdminPage = () => {
  const [tab, setTab] = React.useState('matches');
  const [scoreForm, setScoreForm] = React.useState({ matchId: '', home: '', away: '' });
  const [syncDone, setSyncDone] = React.useState(false);
  const [syncing, setSyncing] = React.useState(false);

  const md1 = WC_FIXTURES.filter(f => f.matchday === 1);

  const tabStyle = (id) => ({
    flex: 1, height: 34, border: 'none', cursor: 'pointer', borderRadius: 6,
    background: tab === id ? 'var(--surface)' : 'none',
    color: tab === id ? 'var(--text-primary)' : 'var(--text-muted)',
    fontSize: 12, fontWeight: 700,
  });

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => { setSyncing(false); setSyncDone(true); }, 1800);
  };

  const inputStyle = {
    padding: '8px 10px', borderRadius: 8, border: '1px solid var(--border)',
    background: 'var(--surface-alt)', color: 'var(--text-primary)', fontSize: 13,
    fontFamily: 'inherit', outline: 'none', width: '100%',
  };

  return (
    <div style={{ paddingBottom: 32 }}>
      <h1 style={{ fontSize: 22, fontWeight: 900, color: 'var(--text-primary)', letterSpacing: '-0.02em', marginBottom: 16, paddingTop: 8 }}>
        Admin
      </h1>

      <div style={{ display: 'flex', gap: 4, background: 'var(--surface-alt)', borderRadius: 8, padding: 4, marginBottom: 20 }}>
        <button style={tabStyle('matches')} onClick={() => setTab('matches')}>Matches</button>
        <button style={tabStyle('score')} onClick={() => setTab('score')}>Enter Score</button>
        <button style={tabStyle('sync')} onClick={() => setTab('sync')}>Sync API</button>
      </div>

      {/* Matches tab */}
      {tab === 'matches' && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, overflow: 'hidden' }}>
          <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--border)', fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>
            Matchday 1
          </div>
          {md1.map((f, i) => {
            const home = WC_TEAMS[f.home];
            const away = WC_TEAMS[f.away];
            return (
              <div key={f.id} style={{
                display: 'flex', alignItems: 'center', padding: '10px 14px', gap: 10,
                borderBottom: i < md1.length - 1 ? '1px solid var(--border)' : 'none',
              }}>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'monospace', minWidth: 36 }}>{f.id}</span>
                <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>
                  {home?.short} vs {away?.short}
                </span>
                <StatusBadge status={f.status} />
                {f.status === 'finished' && (
                  <button style={{
                    background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.25)',
                    borderRadius: 6, padding: '4px 10px', cursor: 'pointer',
                    fontSize: 11, fontWeight: 700, color: 'var(--green)',
                  }}>
                    Score →
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Enter score */}
      {tab === 'score' && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: 20 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Match ID</label>
              <input style={inputStyle} placeholder="e.g. M001" value={scoreForm.matchId} onChange={e => setScoreForm(p => ({ ...p, matchId: e.target.value }))} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Home goals</label>
                <input style={inputStyle} type="number" min="0" placeholder="0" value={scoreForm.home} onChange={e => setScoreForm(p => ({ ...p, home: e.target.value }))} />
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Away goals</label>
                <input style={inputStyle} type="number" min="0" placeholder="0" value={scoreForm.away} onChange={e => setScoreForm(p => ({ ...p, away: e.target.value }))} />
              </div>
            </div>
            <button
              style={{
                height: 44, borderRadius: 8, border: 'none', cursor: 'pointer',
                background: scoreForm.matchId ? 'var(--green)' : 'var(--surface-alt)',
                color: scoreForm.matchId ? '#000' : 'var(--text-muted)', fontWeight: 800, fontSize: 13,
              }}
            >
              Save Score
            </button>
          </div>
        </div>
      )}

      {/* Sync API */}
      {tab === 'sync' && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: 24, textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}><IconSync size={40} /></div>
          <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>Sync from football-data.org</p>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 20 }}>
            {syncDone ? 'Last synced: just now' : 'Last synced: never'}
          </p>
          <button
            onClick={handleSync}
            disabled={syncing}
            style={{
              height: 44, minWidth: 160, borderRadius: 8, border: 'none', cursor: syncing ? 'not-allowed' : 'pointer',
              background: syncDone ? 'rgba(34,197,94,0.1)' : 'var(--green)',
              color: syncDone ? 'var(--green)' : '#000', fontWeight: 800, fontSize: 13,
              opacity: syncing ? 0.7 : 1,
            }}
          >
            {syncing ? 'Syncing…' : syncDone ? '✓ Synced' : 'Sync Now'}
          </button>
        </div>
      )}
    </div>
  );
};

Object.assign(window, { ScoreBreakdown, PredictionRow, MyPicksPage, AdminPage });
