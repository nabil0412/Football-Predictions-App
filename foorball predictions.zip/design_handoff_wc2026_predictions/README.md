# Handoff: WC 2026 Predictions App

## Overview

A full-product design for a FIFA World Cup 2026 football prediction game. Users pick match scores, use wildcards (Confidence / Underdog / Chaos), compete in a global leaderboard, create private leagues, and pick a "captain" team to follow through the tournament.

## About the Design Files

The files in this bundle are **high-fidelity HTML prototypes** — not production code. They demonstrate the intended look, layout, component hierarchy, and interactions. Your task is to **recreate these designs in your existing codebase** (Next.js, React, etc.) using your established patterns, libraries (Clerk for auth, your ORM for data, etc.) — do not ship these HTML files directly.

Open `WC 2026 Predictions.html` in a browser to see the full interactive prototype. All navigation, prediction picking, leaderboard, leagues, and captain picker are wired up with local state.

## Fidelity

**High-fidelity.** Pixel-accurate colors, spacing, typography, and interaction states. Recreate the UI precisely using your codebase's design system. The prototype uses real WC 2026 teams and representative fixture data (groups and fixtures are approximate — replace with your real database).

---

## Design Tokens

### Colors ("Pitch Night" dark palette)

```
--bg:             #080e1a   Page background (deep midnight)
--surface:        #0f1929   Cards, panels
--surface-alt:    #162032   Elevated / nested surfaces
--border:         #1e293b   Dividers, card borders
--text-primary:   #f1f5f9   Headings, key data
--text-secondary: #94a3b8   Labels, subtitles
--text-muted:     #475569   Timestamps, metadata
--green:          #22c55e   CTAs, active states, correct predictions, primary brand
--red:            #f87171   Live match indicator ONLY
```

> **Color rules:**
> - Green = every interactive/positive element. CTAs, active nav, selected state, positive points, correct predictions.
> - Red = live match indicators only. Nothing else.
> - No yellow/gold anywhere.
> - All chrome, borders, badges default to the neutral surface/text palette.

### Typography

**Font:** Inter (Google Fonts). Load weights 400, 500, 600, 700, 800, 900.

| Role              | Size  | Weight | Notes                            |
|-------------------|-------|--------|----------------------------------|
| Page title        | 26px  | 900    | Letter-spacing: -0.02em          |
| Section header    | 11px  | 700    | Uppercase, letter-spacing: 0.1em |
| Card title        | 15px  | 700    |                                  |
| Body              | 14px  | 400–500|                                  |
| Meta / timestamp  | 11px  | 400    |                                  |
| Score (large)     | 30px  | 900    | tabular-nums, letter-spacing: -0.03em |
| Score (mid)       | 18px  | 800    |                                  |
| Hero number       | 52px  | 900    | letter-spacing: -0.04em          |

### Spacing & Radius

- Base unit: 8px
- Card border-radius: 16px (main cards), 10–12px (inner elements), 99px (pills/badges)
- Card padding: 14–20px
- Section gap: 44px top margin before section dividers
- Card list gap: 10–12px between stacked cards
- Max content width: 720px (centered), 1024px for admin

### Shadows

Cards on hover: `box-shadow: 0 8px 24px rgba(0,0,0,0.3)` with `transform: translateY(-1px)`

---

## Screens

### 1. Homepage — Fixture List (`/`)

**Layout:** Sticky navbar → hero section → optional today strip → scrollable match sections.

**Hero section:**
- Dark green gradient background: `linear-gradient(160deg, #0a1f12 0%, #0b1629 50%, #080e1a 100%)`
- Subtle grid texture overlay (opacity 0.03)
- Left: "FIFA WORLD CUP 2026" label (green, 11px uppercase) → "Predictions" h1 (28px, 900) → green 2px divider bar → "48 teams · 104 matches · Jun 11 – Jul 19" (13px, text-secondary)
- Right: Large countdown number in green (52px, 900) + "days to go" label. During tournament: current matchday label.
- Bottom of hero: mini stats row (Picks / Rank / Points) separated by a subtle border-top.

**Today strip** (visible when there are live/locked matches):
- Background: `rgba(34,197,94,0.04)`, border: `rgba(34,197,94,0.25)`
- Pulsing green dot + "Live Now" or "Today" label
- Lists live/locked match cards inline

**Match sections:**
- `SectionDivider` with matchday label + date range, green dot if active
- Matches grouped by date within each section; date label in text-muted uppercase
- Each matchday is tappable to collapse/expand

**Stages in order:** Matchday 1 → Matchday 2 → Matchday 3 → Round of 32 → Round of 16 → Quarter-finals → Semi-finals → Third place → Final

---

### 2. Match Card Component

The most important component. Four states:

**Upcoming:**
```
[top meta: Group X · small muted text]
[Flag] TeamA    18:00     TeamB [Flag]
                FRI 13 JUN
[bottom strip: green tinted bg] Predict this match →
```
- On hover: `translateY(-1px)` + box-shadow, border turns green

**Live:**
```
[top meta: Group X]                [LIVE badge: red bg, pulsing dot]
[Flag] TeamA    2 — 1     TeamB [Flag]
                  67'
```
- Card background: `rgba(248,113,113,0.03)`, border: `rgba(248,113,113,0.25)`
- No CTA strip

**Finished:**
```
[top meta: Group X]                [FT badge: surface-alt bg]
[Flag] TeamA    2 — 1     TeamB [Flag]
                Full Time
```
- Tapping expands score breakdown inline

**Locked (< 1hr before kickoff):**
```
[top meta]                         [Locked badge]
[Flag] TeamA    18:00     TeamB [Flag]
                FRI 13 JUN
                Locked — predictions closed
```
- Time color stays text-primary (no yellow)

**My pick chip** (shows if user has a prediction):
- Subtle surface-alt pill below the score row: "My pick: 2–0 🎯 +8 pts"
- Points text green if positive, red if negative

**Status badge styles:**
| Status   | Background     | Text color        | Border                   |
|----------|----------------|-------------------|--------------------------|
| LIVE     | `#f87171`      | `#fff`            | none; pulsing dot inside |
| FT       | `var(--surface-alt)` | `var(--text-muted)` | none             |
| Locked   | `var(--surface-alt)` | `var(--text-secondary)` | `var(--border)` |
| Upcoming | transparent    | `var(--text-muted)` | `var(--border)`        |

---

### 3. Prediction Page (`/predict/[matchId]`)

**Layout:** Back arrow → match header card → score picker card → wildcard card → save button.

**Match header card:**
- Meta line: Group + date
- 3-column grid: [Flag + team name] [time + venue] [team name + Flag]

**Score pickers:**
- Two rows (home team / away team), each with 5 buttons: 0 · 1 · 2 · 3 · 4+
- Button: `minHeight: 48px`, `borderRadius: 10px`, full-width within row, `flex: 1`
- Inactive: `background: var(--surface-alt)`, `border: 1.5px solid var(--border)`, `color: var(--text-secondary)`
- Active: `background: var(--green)`, `border: 1.5px solid var(--green)`, `color: #000`
- Auto-derived result chip: green-tinted pill, e.g. "Result: Brazil win"

**Wildcard section** (3 cards stacked):
- Each card: icon (24px emoji) + name (13px 700) + description (12px muted) + badge pill (right)
- Inactive: `background: var(--surface-alt)`, `border: 1.5px solid var(--border)`
- Active: `background: rgba(34,197,94,0.06)`, `border: 1.5px solid var(--green)`
- Badge: inactive = neutral border/muted text; active = green border + green text
- Wildcards: 🎯 Confidence (×2 pts) · ⚡ Underdog (+3 bonus) · 🎲 Chaos Card (Risk/reward)

**Chaos event sub-picker** (appears when Chaos Card selected):
- 3 cards in a row: Common (+1) · Medium (+2) · Rare (+3)
- Colors: text-muted / text-secondary / text-primary (no special accent colors)

**Save button:**
- Full width, `height: 52px`, `borderRadius: 12px`
- Disabled (no score selected): `background: var(--surface-alt)`, `color: var(--text-muted)`
- Enabled: `background: var(--green)`, `color: #000`, `fontWeight: 800`
- After save: transitions to "✓ Saved!" then navigates back

---

### 4. My Picks (`/my-picks`)

**Header:** "My Picks" (26px 900) + total points counter (28px 900, green, right-aligned).

**Tabs:** Upcoming · Finished (segmented, surface-alt background)

**Prediction row:**
- Flags + team names + "vs" separator
- "My pick: 2–1 🎯" below in text-secondary
- Stage + date + live indicator (red if live)
- Right: Edit button (upcoming) or +N pts badge (finished)
- Tapping a finished row expands the score breakdown

**Score breakdown (expanded):**
- Match result vs your pick header
- Each row: small green/gray dot + label + points (right-aligned, green if correct)
- Divider + Total row (bold, green/red)

**Empty state:** "⚽ No picks yet" + "Browse matches →" link

---

### 5. Leaderboard (`/leaderboard`)

**Header:** "Leaderboard" + player count + "Your rank: #N" chip (green tinted).

**Podium (top 3):**
- Flex row, `alignItems: flex-end`
- Column order: 2nd · 1st · 3rd (silver/gold/bronze display order)
- Heights of podium blocks: 140px / 160px / 120px
- Medal emoji + avatar + first name + points above each podium block
- Podium blocks: all `background: var(--surface-alt)`, uniform border
- Entrance: `scaleY` animation from bottom, staggered 0.1s delay per column

**List rows (4th onwards):**
- Rank number (28px col) + Avatar (34px) + Name + Progress bar (80px, hidden mobile) + Points
- "You" row: `background: rgba(34,197,94,0.05)`, `border: rgba(34,197,94,0.2)`, name in green, pulse animation on load
- Progress bar: width = `(points / maxPoints) * 100%`; your bar is green, others are text-muted

---

### 6. Leagues (`/leagues`)

**Tabs:** My Leagues · Create · Join

**My Leagues — league card:**
- "🏆 League Name" + member count (right)
- Rank/points line + "View →" link
- Invite code in monospace at bottom-left

**Create tab:** Name input → "Create League" button → success state shows generated code with copy button.

**Join tab:** Monospace uppercase code input (8 chars max) → "Join League" button.

---

### 7. League Detail (`/leagues/[id]`)

**Header:** League name + member count + copyable invite code chip (right).

**Members table:** Full-width card, rows separated by border.
- Rank · Avatar · Name + progress bar · Points + diff-from-leader
- "You" row highlighted green
- Rank 1 diff shows "Leader" in green; others show "–N" in text-muted

---

### 8. Captain Picker (`/captain`)

**Scoring banner:** `var(--surface-alt)` card listing +1/+1/+2/+2/+3/+5 points per round. Locks deadline below.

**Team grid:** 4 columns desktop, 2 columns mobile.
- Each cell: Flag (32px) + team short code (11px 600)
- Inactive: `background: var(--surface)`, `border: 1px solid var(--border)`
- Selected: `background: rgba(34,197,94,0.08)`, `border: 2px solid var(--green)` + green ✓ overlay (top-right)
- Confirmed captain: green "Captain" badge above cell; all others fade to opacity 0.4
- Grid organized by group with "Group A" etc. section headers

**Confirm button:** Full width, green when team selected, disabled after confirmation.

---

### 9. Admin (`/admin`)

Three tabs: Matches · Enter Score · Sync API. Functional/data-table aesthetic, no decorative elements.

**Matches tab:** List of all matches with ID, team names, status badge, and "Score →" button for finished matches.

**Enter Score:** Match ID input + home goals + away goals + Save button.

**Sync API:** Single "Sync Now" button → loading state → "✓ Synced" confirmation.

---

## Navbar

**Desktop (≥640px):** Sticky, 56px tall, `backdrop-filter: blur(20px)`.
- Left: ⚽ logo mark (30×30px, green bg, 8px radius) + "WC 2026" wordmark
- Center: Matches · Leaderboard · Leagues · My Picks — pill highlight for active (`rgba(34,197,94,0.12)`)
- Right: "Captain" button (surface-alt, neutral border) + avatar circle (YO initials)

**Mobile (<640px):** Bottom fixed nav, 60px tall. 5 tabs: Matches · Ranks · Leagues · My Picks · Captain. Active tab in green.

---

## Animations & Interactions

| Element                | Behavior                                                        |
|------------------------|-----------------------------------------------------------------|
| Match card (upcoming)  | `translateY(-1px)` + box-shadow on hover; tap → prediction page |
| Live dot               | `pulseDot` keyframe: scale 1→0.7→1, opacity 1→0.4→1, 1.4s loop |
| Podium blocks          | `scaleY` from 0→1 (transform-origin: bottom), staggered         |
| "You" leaderboard row  | `pulseMe` box-shadow pulse, once on load, 0.5s delay            |
| Score breakdown        | `slideUp` (translateY 8px→0, opacity 0→1) on expand            |
| Save button            | Color transition 0.2s; shows "✓ Saved!" then auto-navigates     |
| Copy invite code       | Copies to clipboard → toast notification for 2.4s               |

---

## Flags

Use [flagcdn.com](https://flagcdn.com) for country flags:
- 40px width: `https://flagcdn.com/w40/{iso2}.png`
- 80px width: `https://flagcdn.com/w80/{iso2}.png`

England uses `gb-eng` (not `gb`). All other teams use standard ISO 3166-1 alpha-2 codes.

**All 48 teams and their flag codes** are in `wc-data.js` (`WC_TEAMS` object).

---

## Data Model (see `wc-data.js`)

### Team
```ts
{ name: string, short: string, flag: string }
```

### Fixture
```ts
{
  id: string,           // "M001" … "M104"
  home: string,         // team code e.g. "BRA"
  away: string,
  group: string | null, // "A"–"L" or null for knockout
  matchday: number | null,
  stage: string,        // "Group Stage" | "Round of 32" | "Round of 16" | "Quarter-finals" | "Semi-finals" | "Third place" | "Final"
  date: string,         // "2026-06-11"
  time: string,         // "16:00"
  venue: string,
  status: "upcoming" | "live" | "locked" | "finished",
  homeScore: number | null,
  awayScore: number | null,
  minute: number | null,
}
```

### Prediction
```ts
{
  matchId: string,
  homeGoals: number,
  awayGoals: number,
  wildcard: "confidence" | "underdog" | "chaos" | null,
  points: number | null,   // null until match is scored
  breakdown: Array<{ label: string, pts: number, correct: boolean }>,
}
```

### Scoring
| Event                      | Points |
|----------------------------|--------|
| Correct result             | +3     |
| Correct home goals         | +1     |
| Correct away goals         | +1     |
| Perfect prediction (exact) | +1     |
| Confidence wildcard        | ×2 total |
| Underdog wildcard          | +3 if underdog wins |
| Chaos – Common             | +1     |
| Chaos – Medium             | +2     |
| Chaos – Rare               | +3     |
| Captain team: R32 win      | +1     |
| Captain team: R16 win      | +1     |
| Captain team: QF win       | +2     |
| Captain team: SF win       | +2     |
| Captain team: Final        | +3     |
| Captain team: Winner       | +5     |

---

## Files in This Bundle

| File                      | Purpose                                              |
|---------------------------|------------------------------------------------------|
| `WC 2026 Predictions.html`| Main prototype entry point — open in browser         |
| `wc-data.js`              | All 48 teams, 12 groups, fixture generator, mock data|
| `wc-components.jsx`       | Flag, StatusBadge, Avatar, MatchCard, Navbar, BottomNav, icons |
| `wc-pages-main.jsx`       | HomePage, PredictionPage, CaptainPage                |
| `wc-pages-social.jsx`     | LeaderboardPage, LeaguesPage, LeagueDetailPage       |
| `wc-pages-other.jsx`      | MyPicksPage, AdminPage, ScoreBreakdown               |
| `wc-app.jsx`              | App root: routing, state, localStorage persistence   |
| `tweaks-panel.jsx`        | Prototype-only tweak panel (ignore in production)    |

> **Note:** `tweaks-panel.jsx` is a design-preview utility only — ignore it in production. The `demoMode` tweak in `wc-app.jsx` overlays fake live/finished states onto fixtures for design review; remove this in production.
